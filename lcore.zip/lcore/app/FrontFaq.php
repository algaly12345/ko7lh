<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FrontFaq extends Model
{
    protected $guarded = ['id'];
}
