<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PackageModules extends Model
{
    protected $guarded = [];
    public $timestamps = false;
}
