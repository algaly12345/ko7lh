<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GoogleCaptchaSetting extends Model
{
    //
}
