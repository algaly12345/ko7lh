# Readme for Appointo multi-vendor

### Plugins used in the app

<ol>
    <li>
        <strong>Croppie (used for front page silder in superadmin panel) </strong> - <a href=“https://foliotek.github.io/Croppie/”>foliotek.github.io/Croppie/</a>
    </li>    
    <li>
        <strong>FullCalendar</strong> - <a href=“https://fullcalendar.io”>fullcalendar.io</a>
    </li>    
    <li>
        <strong>Select2</strong> - <a href=“https://select2.org/”>select2.org</a>
    </li>    
    <li>
        <strong>Dropify</strong> - <a href=“https://jeremyfagis.github.io/dropify/”>jeremyfagis.github.io/dropify</a>
    </li>    
    <li>
        <strong>DropzoneJS</strong> - <a href=“https://www.dropzonejs.com/”>www.dropzonejs.com</a>
    </li>    
    <li>
        <strong>Summernote</strong> - <a href=“https://summernote.org/”>summernote.org</a>
    </li>
    <li>
        <strong>Datepicker</strong> - <a href=“https://getdatepicker.com/4/”>getdatepicker.com/4</a>
    </li>    
    <li>
        <strong>Timepicker</strong> - <a href=“https://github.com/jdewit/bootstrap-timepicker”>github.com/jdewit/bootstrap-timepicker</a>
    </li>    
    <li>
        <strong>Colorpicker</strong> - <a href=“https://itsjavi.com/bootstrap-colorpicker/”>itsjavi.com/bootstrap-colorpicker</a>
    </li>    
    <li>
        <strong>Date Range Picker</strong> - <a href=“https://github.com/dangrossman/daterangepicker”>github.com/dangrossman/daterangepicker</a>
    </li>    
    <li>
        <strong>Ace Code Editor</strong> - <a href=“https://ace.c9.io/”>ace.c9.io</a>
    </li>    
    <li>
        <strong>chart.js v2.7.3 </strong> - <a href=“https://www.chartjs.org”>www.chartjs.org</a>
    </li>
    <li>
        <strong>bootstrap-tagsinput</strong> - <a href=“https://bootstrap-tagsinput.github.io/bootstrap-tagsinput/examples/”>bootstrap-tagsinput.github.io/bootstrap-tagsinput/examples</a>
    </li>
    <li>
        <strong>SweetAlert</strong> - <a href=“https://sweetalert.js.org/”>sweetalert.js.org</a>
    </li>
    <li>
        <strong>google-reptcha (version2 and version3)</strong>
    </li>
    <li>
        <strong>Sortable | jQuery UI </strong> - <a href=“https://jqueryui.com/sortable/”>jqueryui.com/sortable</a>
    </li>
    <li>
        <strong>Location Picker</strong> - <a href=“https://github.com/Logicify/jquery-locationpicker-plugin”>github.com/Logicify/jquery-locationpicker-plugin</a>
    </li>
    <li>
        <strong>Owl Carousel</strong> - <a href=“https://owlcarousel2.github.io/OwlCarousel2/”>owlcarousel2.github.io/OwlCarousel2</a>
    </li>
    <li>
        <strong>jQuery Lazy (Image Lazy Load on Front)</strong> - <a href=“http://jquery.eisbehr.de/lazy/”>jquery.eisbehr.de/lazy</a>
    </li>
</ol>
