<?php

return array (
  'title' => 'تنصيب Laravel',
  'next' => 'متابعة',
  'welcome' => 
  array (
    'title' => 'تنصيب Laravel',
    'message' => 'أهلا بك في صفحة تنصيب Laravel',
  ),
  'requirements' => 
  array (
    'title' => 'المتطلبات',
  ),
  'permissions' => 
  array (
    'title' => 'تراخيص المجلدات',
  ),
  'environment' => 
  array (
    'title' => 'الإعدادات',
    'save' => 'حفظ ملف .env',
    'success' => 'تم حفظ الإعدادات بنجاح',
    'errors' => 'حدث خطأ أثناء إنشاء ملف .env. رجاءا قم بإنشاءه يدويا',
  ),
  'final' => 
  array (
    'title' => 'النهاية',
    'finished' => 'تم تنصيب البرنامج بنجاح...',
    'exit' => 'إضغط هنا للخروج',
  ),
);
